#!/usr/bin/env python3
import os
import sys
import yaml
import signal
from action_msgs.msg import GoalStatus

import rclpy
from robot_communication.action import JitsiAction
from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.node import Node


def handler(signal_received, frame):
    # Handle any cleanup here
    print('SIGINT or CTRL-C detected. Exiting gracefully')
    raise RuntimeError("")


def read_init_params():
    params_file = "init.conf"
    if not os.path.isfile(params_file):
        print("App params file <{}> does not exist".format(params_file))
        sys.exit(1)
    with open(params_file, "r") as stream:
        try:
            params = yaml.safe_load(stream)
            return params
        except yaml.YAMLError as exc:
            print(exc)
            sys.exit(1)
        except Exception as exc:
            print(exc)
            sys.exit(1)


class JitsiClient(Node):

    def __init__(self):
        super().__init__('jitsi_client')
        self._action_client = ActionClient(self, JitsiAction, '/jitsi_action')

    def cancel_done(self, future):
        cancel_response = future.result()
        if len(cancel_response.goals_canceling) > 0:
            self.get_logger().info('Goal successfully canceled')
        else:
            self.get_logger().info('Goal failed to cancel')

        rclpy.shutdown()

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return

        self._goal_handle = goal_handle

        self.get_logger().info('Goal accepted :)')

    def feedback_callback(self, feedback):
        self.get_logger().info(
            'Received feedback: {0}'.format(feedback.feedback.sequence))

    def cancel(self):
        self.get_logger().info('Canceling goal')
        # Cancel the goal
        future = self._goal_handle.cancel_goal_async()
        future.add_done_callback(self.cancel_done)

    def send_goal(self, username, password):
        self.get_logger().info('Waiting for action server...')
        self._action_client.wait_for_server()

        goal_msg = JitsiAction.Goal()
        goal_msg.username = username
        goal_msg.password = password

        self.get_logger().info('Sending goal request...')

        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback)

        rclpy.spin_until_future_complete(self, self._send_goal_future)

        goal_handle = self._send_goal_future.result()
        self._goal_handle = goal_handle
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return

        self.get_logger().info('Goal accepted :)')
        resp = goal_handle.get_result_async()

        # Get future
        rclpy.spin_until_future_complete(self, resp)

        result = resp.result().result
        status = resp.result().status


def app_main(params=()):
    print("Jitsi-meet room handler is Alive!")
    # Add signal handler
    signal.signal(signal.SIGTERM, handler)
    signal.signal(signal.SIGINT, handler)

    rclpy.init(args=None)
    action_client = JitsiClient()

    # Make a dictionary from the loaded params
    new_params = {}
    for par in params["params"]:
        new_params[par["name"]] = par["value"]

    try:
        action_client.send_goal(new_params["username"], new_params["password"])
    except Exception as exc:
        action_client.cancel()

    print("Jitsi-meet room handler Exiting!")


if __name__ == "__main__":
    app_params = read_init_params()
    try:
        app_main(app_params)
    except Exception as exc:
        print(exc)
        sys.exit(1)
