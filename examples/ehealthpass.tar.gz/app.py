import requests
import json
import sys
import base64
import time
import os
from random import random
from src.connect_mini import Connect
import yaml

import logging
from r4a_apis.utilities import *
from r4a_apis.tek_nodes import *

from r4a_apis.robot_api import RobotAPI
from r4a_apis.cloud_api import CloudAPI
from r4a_apis.generic_api import GenericAPI

from google.cloud import speech
from google.cloud.speech import enums
from google.cloud.speech import types

from src.text2speech import textToSpeech
from src.speech2text import speechToText


class Main:
    """ A <<Controller>> class """

    def __init__(self, username, password):
        os.environ["TEKTRAIN_NAMESPACE"] = "elsa"

        log = Logger(allow_cutelog=False, level=logging.DEBUG)
        self.rapi = RobotAPI(logger=log)

        path = os.path.abspath(os.path.dirname(__file__))
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = \
            path + "/elsa-277912-3dfe30a8f65b.json"

        self.username = '{}_{}'.format(username, random())

        self.conn = Connect(username, password)
        self.token = self.conn.login()

        self.url = "http://51.145.193.230:5005/webhooks/rest/webhook"

        self.speechobj = speech.SpeechClient()

        self.config = types.RecognitionConfig(
            encoding=enums.RecognitionConfig.AudioEncoding.LINEAR16,
            sample_rate_hertz=44100,
            language_code='el-GR')

        self.textobj = textToSpeech()

    def start(self, appid=0):

        if appid == 1:
            self.message('Κλείσω ραντεβού')
        else:
            self.user_output('Γεια σου. Ονομάζομαι Έλσα. Πώς θα μπορούσα να σας εξυπηρετήσω;', way="google")

        while True:
            txt = self.user_input()
            self.message(txt)
        return

    def message(self, text):

        metadata = self.conn.get_token()
        data = '{"sender": "' + self.username + '", "message": "' +  text  +'", "metadata": "'+ metadata + '"}'
        data = data.encode('utf-8')

        response = requests.post(self.url, data=data)
        data = json.loads(response.text)

        flag = False
        for item in data:
            if item['text'][:4] == 'Form':
                flag = True
            else:
                msg = item['text'].strip()
                print(msg)
                self.user_output(msg)
        if flag:
        	sys.exit(0)

    def user_input(self, way='speech'):

        if way == "speech":

            flag = True
            while flag:
                # show green image to display starting recording
                out = self.rapi.showColor(InputMessage({
                    'color': Colors.GREEN.value,
                    'duration': 1
                }))

                # Record to file
                out = self.rapi.recordSound(InputMessage({
                    'name': 'eHealthPass',
                    'duration': 5,
                    'save_file_url': '/tmp/tmp.wav'
                }))
                sound_str = out.data['record']

                # show red image to display recording stopped
                out = self.rapi.showColor(InputMessage({
                    'color': Colors.RED.value,
                    'duration': 1
                }))

                audio = {
                    'content': base64.b64decode(sound_str)
                }

                command = self.speechobj.recognize(self.config, audio)
                if len(command.results) == 0:
                    command = ''
                    time.sleep(5)
                else:
                    command = command.results[0].alternatives[0].transcript
                    flag = False

            print(command)
            return command
        else:
            command = input('User input =  ')
            return command

    def user_output(self, text, way="google"):

        if way == "google":

	        # num_files = 0
	        # num_files = len([f for f in os.listdir(path)
	        #     if os.path.isfile(os.path.join(path, f))])

	        filename = 'outputX.wav'  # './outputs/output{}.wav'.format(num_files + 1)
	        self.textobj.t2s(text, filename)
	        out = self.rapi.replaySound(InputMessage({
                'is_file': True,
                'string': filename,
                'volume': 30
            }))

        else:

            self.rapi.speak(InputMessage({
                	'texts': [text],
                    'volume': 10,
                    'language': Languages.EL
                }))


def read_init_params():
    params_file = 'init.conf'
    if not os.path.isfile(params_file):
        print('App params file <{}> does not exist'.format(params_file))
        sys.exit(1)
    with open(params_file, 'r') as stream:
        try:
            params = yaml.safe_load(stream)
            return params
        except yaml.YAMLError as exc:
            print(exc)
            sys.exit(1)
        except Exception as exc:
            print(exc)
            sys.exit(1)


if __name__ == '__main__':

    try:

        app_params = read_init_params()
        username = app_params['params'][0]['value']
        password = app_params['params'][1]['value']

        m = Main(username, password)

        m.start()

    except Exception as exc:

        print(exc)
        sys.exit(1)
