import io
import os
import base64

# Imports the Google Cloud client library
from google.cloud import speech
from google.cloud.speech import enums
from google.cloud.speech import types

class speechToText():
    ''' A Speech to Text class '''

    def __init__(self, lang='el-GR', hertz=44100):
        # Instantiates a client
        self.client = speech.SpeechClient()

        self.config = types.RecognitionConfig(
            encoding=enums.RecognitionConfig.AudioEncoding.LINEAR16,
            sample_rate_hertz=hertz,
            language_code='el-GR')


    def s2t(self, dirn='../resources', filename='untitled.wav'):
        # The name of the audio file to transcribe
        file_name = os.path.join(
            os.path.dirname(__file__),
            dirn,
            filename)

        # Loads the audio into memory
        with io.open(file_name, 'rb') as audio_file:
            content = audio_file.read()
            audio = types.RecognitionAudio(content=content)

        # Detects speech in the audio file
        response = self.client.recognize(self.config, audio)

        # for result in response.results:
        #     print('Transcript: {}'.format(result.alternatives[0].transcript))

        return response


    def s2tB64(self, sound_str):
        # The name of the audio file to transcribe
        audio = {
            'content': base64.b64decode(sound_str)
        }

        response = self.client.recognize(self.config, audio)
        # if len(response.results) == 0:
        #     response = ''
        # else:
        #     response = response.results[0].alternatives[0].transcript

        return response
