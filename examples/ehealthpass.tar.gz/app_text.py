import requests
import json
import sys
import base64
import time
import os
from random import random
from src.connect_mini import Connect


class Main:
    """ A <<Controller>> class """

    def __init__(self, username, password):

        self.username = '{}_{}'.format(username, random())

        self.conn = Connect(username, password)
        self.conn.login()

        self.metadata = self.conn.get_token()

        self.url = "http://51.145.193.230:5005/webhooks/rest/webhook"


    def start(self, appid=0):

        if appid == 1:
            self.message('Κλείσω ραντεβού')
        if appid == 2:
            self.message('Ακυρώσω ραντεβού')
        else:
            print('Γεια σου. Ονομάζομαι Έλσα. Πώς θα μπορούσα να σας εξυπηρετήσω;')

        while True:
            txt = input('User input = ')
            self.message(txt)
        return

    def message(self, text):

        # print(metadata)
        data = '{"sender": "' + self.username + '", "message": "' +  text  +'", "metadata": "'+ self.metadata + '"}'
        data = data.encode('utf-8')

        response = requests.post(self.url, data=data)
        data = json.loads(response.text)

        flag = False
        for item in data:
            if item['text'][:4] == 'Form':
                flag = True
            else:
                print(item['text'])
        if flag:
        	sys.exit(0)



if __name__ == '__main__':

    username = "testpatient3"
    password = "test"
    
    m = Main(username, password)

    m.start()
