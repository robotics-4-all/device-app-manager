import time
import requests

class Connect():
    ''' A class to connect to eHealthPass medical data for the patient X '''

    def __init__(self, username, password):
        self.token = None
        self.expires = 0
        self.domain = 'https://ehealthpass-prod.gnomon.com.gr/'
        self.username = username
        self.password = password

    def login(self):

        url = self.domain + 'AuthenticationService/rest/register/login'

        payload = 'username={}&password={}'.format(self.username, self.password)
        headers = {
          'Content-Type': 'text/plain',
          'Content-Type': 'application/x-www-form-urlencoded'
        }

        response = requests.request("POST", url, headers=headers, data = payload)

        if response.status_code == 200:

            data = response.json()  # dictionary
            self.token = data["access_token"]

            current_time_sec = int(time.time())
            self.expires = current_time_sec + data["expires_in"]

            print("Login Successful.")
            return True
        else:
            self.token = None
            print("Login Failed.")
            return False

    def notify(self):

        if not self.login():
            return False

        url = self.domain + 'PhrService/rest/v2/notification/panic'

        payload = {}
        headers = {'Authorization': 'Bearer {}'.format(self.token)}
                   # ,'Cookie': 'JSESSIONID=F1A494ACAE102AABB27D0CA9C2382864'}

        response = requests.request("POST", url, headers=headers, data = payload)

        if response.status_code == 200:
            print("Notification Successful.")
            return True
        print("Notification Failed.")
        return False


if __name__ == '__main__':
    conn = Connect("testpatient3", "test")
    conn.login()
