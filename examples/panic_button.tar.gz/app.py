import sys
import os
import yaml
import time
import requests

import base64

from r4a_apis.utilities.logger import Logger
from r4a_apis.utilities import InputMessage
from r4a_apis.tek_nodes import *
from r4a_apis.robot_api import RobotAPI
from r4a_apis.cloud_api import CloudAPI
from r4a_apis.generic_api import GenericAPI

from google.cloud import texttospeech


class Connect():
    ''' A class to connect to eHealthPass medical data for the patient X '''

    def __init__(self, username, password):
        self.token = None
        self.expires = 0
        self.domain = 'https://ehealthpass-prod.gnomon.com.gr/'
        self.username = username
        self.password = password

	# Google text to speech configuration
        path = os.path.abspath(os.path.dirname(__file__))
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = \
            path + "/elsa-277912-3dfe30a8f65b.json"

        self.client = texttospeech.TextToSpeechClient()

        self.audio_config = texttospeech.AudioConfig(
            audio_encoding = texttospeech.AudioEncoding.LINEAR16,
            sample_rate_hertz = 44100)

        self.voice = texttospeech.VoiceSelectionParams(\
            language_code = 'el-GR',\
            ssml_gender = texttospeech.SsmlVoiceGender.NEUTRAL)

    def speak(self, text = "default", filepath = "default.wav"):
        synthesis_input = texttospeech.SynthesisInput(text = text)
        response = self.client.synthesize_speech(input = synthesis_input, \
            voice = self.voice, audio_config = self.audio_config)
        record = base64.b64encode(response.audio_content).decode("ascii")
        with open(filepath, 'wb') as out:
            out.write(response.audio_content)
            print('Audio output from Google written')

    def login(self):

        url = self.domain + 'AuthenticationService/rest/register/login'

        payload = 'username={}&password={}'.format(self.username, self.password)
        headers = {
          'Content-Type': 'text/plain',
          'Content-Type': 'application/x-www-form-urlencoded'
        }

        response = requests.request("POST", url, headers=headers, data = payload)

        if response.status_code == 200:

            data = response.json()  # dictionary
            self.token = data["access_token"]

            current_time_sec = int(time.time())
            self.expires = current_time_sec + data["expires_in"]

            print("Login Successful.")
            return True
        else:
            self.token = None
            print("Login Failed.")
            return False

    def notify(self):

        if not self.login():
            return False

        url = self.domain + 'PhrService/rest/v2/notification/panic'

        payload = {}
        headers = {'Authorization': 'Bearer {}'.format(self.token)}
                   # ,'Cookie': 'JSESSIONID=F1A494ACAE102AABB27D0CA9C2382864'}

        response = requests.request("POST", url, headers=headers, data = payload)

        if response.status_code == 200:
            print("Notification Successful.")
            return True
        print("Notification Failed.")
        return False


def read_init_params():
    params_file = 'init.conf'
    if not os.path.isfile(params_file):
        print('App params file <{}> does not exist'.format(params_file))
        sys.exit(1)
    with open(params_file, 'r') as stream:
        try:
            params = yaml.safe_load(stream)
            return params
        except yaml.YAMLError as exc:
            print(exc)
            sys.exit(1)
        except Exception as exc:
            print(exc)
            sys.exit(1)


if __name__ == '__main__':
    try:
        app_params = read_init_params()
        username = app_params['params'][0]['value']
        password = app_params['params'][1]['value']

        conn = Connect(username, password)
        log = Logger(allow_cutelog=False)
        rapi = RobotAPI(logger=log)

        if conn.notify():
            conn.speak(text = 'Οι επαφές έκτακτης ανάγκης ειδοποιήθηκαν για εσάς.', filepath = 'tmp.wav')
            rapi.replaySound(InputMessage({
                'is_file': True,
                'volume': 50,
                'string': 'tmp.wav'
           }))
        else:
            conn.speak(text = 'Συγνώμη, δεν μπορέσαμε να ειδοποιήσουμε τις επαφές έκτακτης ανάγκης.', \
                filepath = 'tmp.wav')
            rapi.replaySound(InputMessage({
                'is_file': True,
                'volume': 50,
                'string': 'tmp.wav'
            }))
    except Exception as exc:
        print("Error")
        print(exc)
        sys.exit(1)
