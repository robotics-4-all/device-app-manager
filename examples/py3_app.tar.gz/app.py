#!/usr/bin/env python3

import time


if __name__ == "__main__":
    while True:
        print('App is Alive!')
        time.sleep(1)
