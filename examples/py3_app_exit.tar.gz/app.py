#!/usr/bin/env python3

import time


if __name__ == "__main__":
    print('App is Alive!')
    print('App Exiting')
    # while True:
    #     print('App is Alive!')
    #     time.sleep(1)
